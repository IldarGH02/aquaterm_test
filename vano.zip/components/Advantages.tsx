
import React from 'react';
import { ICON_MAP, ADVANTAGES } from '../constants';
import { Star } from 'lucide-react';

const Advantages: React.FC = () => {
  return (
    <div className="container mx-auto px-4">
      {/* Header Section */}
      <div className="flex flex-col items-center text-center mb-16">
        <div className="inline-flex items-center space-x-2 text-[#d71e1e] font-black text-xs uppercase tracking-[0.3em] mb-4">
            <Star size={16} fill="currentColor" />
            <span>Ценности компании</span>
        </div>
        <h2 className="text-4xl md:text-5xl font-black text-[#1a224f] mb-6 uppercase tracking-tight">
          ПОЧЕМУ <span className="text-[#d71e1e]">АКВАТЕРМ</span>?
        </h2>
        <div className="w-24 h-1.5 bg-[#d71e1e] rounded-full mb-6"></div>
        <p className="text-gray-600 text-lg max-w-2xl leading-relaxed">
          12 лет мы создаем комфорт в домах жителей Орловской области, 
          сочетая инженерную точность с искренним сервисом.
        </p>
      </div>

      {/* Grid Cards */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
        {ADVANTAGES.map((adv, idx) => {
          const iconElement = ICON_MAP[adv.icon] as React.ReactElement;
          
          return (
            <div key={idx} className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100 group hover:-translate-y-2 relative overflow-hidden">
              {/* Hover Accent */}
              <div className="absolute top-0 left-0 w-1 h-full bg-[#d71e1e] opacity-0 group-hover:opacity-100 transition-opacity"></div>
              
              <div className="w-16 h-16 bg-[#1a224f]/5 rounded-2xl flex items-center justify-center mb-6 text-[#1a224f] group-hover:bg-[#d71e1e] group-hover:text-white transition-colors duration-300">
                {iconElement && React.cloneElement(iconElement, { className: "w-8 h-8" })}
              </div>
              
              <h3 className="text-xl font-black text-[#1a224f] mb-3 group-hover:text-[#d71e1e] transition-colors">
                {adv.title}
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                {adv.desc}
              </p>
            </div>
          );
        })}
      </div>

      {/* Stats Block - Dark Theme */}
      <div className="bg-[#1a224f] rounded-3xl p-10 md:p-14 relative overflow-hidden shadow-2xl">
        {/* Background Patterns */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#d71e1e] opacity-10 rounded-full blur-[100px] translate-x-1/2 -translate-y-1/2"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-400 opacity-5 rounded-full blur-[80px] -translate-x-1/2 translate-y-1/2"></div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-12 text-center relative z-10">
          <div className="flex flex-col items-center group">
            <div className="text-5xl md:text-6xl font-black text-white mb-2 group-hover:scale-110 transition-transform duration-300">10<span className="text-[#d71e1e]">+</span></div>
            <div className="text-[10px] md:text-xs font-bold uppercase tracking-[0.2em] text-blue-200">Лет на рынке</div>
          </div>
          
          <div className="flex flex-col items-center group relative md:before:content-[''] md:before:absolute md:before:left-[-24px] md:before:top-1/4 md:before:h-1/2 md:before:w-[1px] md:before:bg-white/10">
            <div className="text-5xl md:text-6xl font-black text-white mb-2 group-hover:scale-110 transition-transform duration-300">5k<span className="text-[#d71e1e]">+</span></div>
            <div className="text-[10px] md:text-xs font-bold uppercase tracking-[0.2em] text-blue-200">Проектов сдано</div>
          </div>
          
          <div className="flex flex-col items-center group relative lg:before:content-[''] lg:before:absolute lg:before:left-[-24px] lg:before:top-1/4 lg:before:h-1/2 lg:before:w-[1px] lg:before:bg-white/10">
            <div className="text-5xl md:text-6xl font-black text-white mb-2 group-hover:scale-110 transition-transform duration-300">25<span className="text-[#d71e1e]">+</span></div>
            <div className="text-[10px] md:text-xs font-bold uppercase tracking-[0.2em] text-blue-200">Специалистов</div>
          </div>
          
          <div className="flex flex-col items-center group relative md:before:content-[''] md:before:absolute md:before:left-[-24px] md:before:top-1/4 md:before:h-1/2 md:before:w-[1px] md:before:bg-white/10">
            <div className="text-5xl md:text-6xl font-black text-white mb-2 group-hover:scale-110 transition-transform duration-300">3</div>
            <div className="text-[10px] md:text-xs font-bold uppercase tracking-[0.2em] text-blue-200">Магазина в Орле</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Advantages;
